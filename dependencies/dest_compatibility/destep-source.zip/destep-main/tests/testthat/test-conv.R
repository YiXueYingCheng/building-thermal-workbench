test_that("conv__update_names respects table dependencies", {
    dest <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
    on.exit(DBI::dbDisconnect(dest), add = TRUE)

    DBI::dbWriteTable(dest, "BUILDING", data.frame(
        BUILDING_ID = 1L, NAME = "Building"
    ))
    DBI::dbWriteTable(dest, "ROOM", data.frame(
        ID = 1:2, NAME = c(".", ".")
    ))
    DBI::dbWriteTable(dest, "SURFACE", data.frame(
        SURFACE_ID = 11:12, NAME = c(".", "."),
        OF_ROOM = 1:2, TYPE = 0L
    ))
    DBI::dbWriteTable(dest, "MAIN_ENCLOSURE", data.frame(
        SIDE1 = 11:12, SIDE2 = c(NA_integer_, NA_integer_), KIND = 1L
    ))
    DBI::dbWriteTable(dest, "OUTSIDE", data.frame(
        OUTSIDE_ID = integer(), NAME = character()
    ))
    DBI::dbWriteTable(dest, "GROUND", data.frame(
        GROUND_ID = integer(), NAME = character()
    ))
    DBI::dbWriteTable(dest, "SHADING", data.frame(
        ID = integer(), NAME = character()
    ))

    # The caller order is intentionally reversed; dependencies must win.
    conv__update_names(dest, c("SURFACE", "ROOM"))

    expect_equal(DBI::dbReadTable(dest, "ROOM")$NAME, c("Room", "Room 1"))
    expect_equal(
        DBI::dbReadTable(dest, "SURFACE")$NAME,
        c("Room Wall", "Room 1 Wall")
    )
})

test_that("conv__update_names prefixes storeys in multi-building models", {
    dest <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
    on.exit(DBI::dbDisconnect(dest), add = TRUE)

    DBI::dbWriteTable(dest, "BUILDING", data.frame(
        BUILDING_ID = 1:2,
        NAME = c("North Building", "South Building")
    ))
    DBI::dbWriteTable(dest, "STOREY", data.frame(
        ID = 11:12,
        NAME = c(".", "."),
        NO = c(0L, 0L),
        OF_BUILDING = 1:2
    ))

    conv__update_names(dest, "STOREY")

    expect_equal(
        DBI::dbReadTable(dest, "STOREY")$NAME,
        c("North Building Storey 1", "South Building Storey 1")
    )
})

test_that("conv__add_objects expands one EnergyPlus class", {
    ep <- ensure_empty_idf()
    values <- list(
        list(name = "First", hourly_value = 1),
        list(name = "Second", hourly_value = 2)
    )

    out <- conv__add_objects(NULL, ep, "Schedule:Constant", values)

    expect_equal(out$object$class_name, rep("Schedule:Constant", 2L))
    expect_equal(
        out$value[
            field_name == "Name",
            value_chr
        ],
        c("First", "Second")
    )
    expect_null(conv__add_objects(NULL, ep, "Schedule:Constant", list()))
})

test_that("to_eplus() works", {
    skip_on_cran()
    eplusr::use_idd(23.1, "auto")
    ep <- eplusr::empty_idf(23.1)

    path <- ensure_dest_test_file()
    dest <- read_dest(path)
    on.exit(DBI::dbDisconnect(dest), add = TRUE)

    # can insert a comment about the original DeST version in `Version` comment
    expect_equal(
        conv__version_comment(dest, ep)$object$comment[[1]],
        "Converted from DeST v2.6"
    )

    # can update all necessary names before conversion
    conv__update_names(dest)
    expect_equal(DBI::dbReadTable(dest, "STOREY")$NAME, paste("Storey", 1:3))
    expect_true(any(grepl("3-N-1 Wall", DBI::dbReadTable(dest, "SURFACE")$NAME)))
    expect_true(any(grepl("DefaultOutside Wall", DBI::dbReadTable(dest, "SURFACE")$NAME)))
    expect_true(any(grepl("DefaultGround Floor", DBI::dbReadTable(dest, "SURFACE")$NAME)))
    expect_true(all(startsWith(DBI::dbReadTable(dest, "SYS_OUTWALL")$CNAME, "ExtWall - ")))
    expect_true(all(startsWith(DBI::dbReadTable(dest, "SYS_INWALL")$CNAME, "IntWall - ")))
    expect_true(all(startsWith(DBI::dbReadTable(dest, "SYS_ROOF")$CNAME, "Roof - ")))
    expect_true(all(startsWith(DBI::dbReadTable(dest, "SYS_GROUNDFLOOR")$CNAME, "GroundFloor - ")))
    expect_true(all(startsWith(DBI::dbReadTable(dest, "SYS_MIDDLEFLOOR")$CNAME, "Ceiling - ")))

    # can convert 'Building'
    expect_type(bld <- building__convert(dest, ep), "list")
    expect_named(bld, c("object", "value"))
    expect_s3_class(attr(bld, "table"), "data.table")
    # can specify which building to extract
    expect_error(building__convert(dest, ep, TRUE), "integer or character")
    expect_equal(building__convert(dest, ep, 1), building__convert(dest, ep, "国管局1#"))

    # can convert 'Site:Location'
    expect_type(loc <- location__convert(dest, ep), "list")
    expect_named(loc, c("object", "value"))
    expect_s3_class(attr(loc, "table"), "data.table")
    expect_equal(loc$value$value_chr[[1L]], "DefaultEnvironment")

    # can convert 'Zone', 'ZoneList', 'ZoneGroup'
    expect_type(zn <- zone__convert(dest, ep), "list")
    expect_named(zn, c("object", "value"))
    expect_equal(unique(zn$object$class_name), c("Zone", "ZoneList", "ZoneGroup"))
    expect_s3_class(attr(zn, "table"), "data.table")

    # can convert 'Material', 'Construction'
    expect_type(const <- const__convert(dest, ep), "list")
    expect_named(const, c("object", "value"))
    expect_equal(unique(const$object$class_name),
        c(
            "Material", "WindowMaterial:SimpleGlazingSystem", "Construction"
        )
    )
    expect_s3_class(attr(const, "table"), "data.table")

    # can convert 'BuildingSurface:Detailed'
    expect_type(surface <- surface__convert(dest, ep), "list")
    expect_named(surface, c("object", "value"))
    expect_equal(unique(surface$object$class_name), "BuildingSurface:Detailed")
    expect_s3_class(attr(surface, "table"), "data.table")

    # can convert a DeST model to a valid EnergyPlus model
    expect_s3_class(idf <- to_eplus(dest, 23.1), "Idf")
    expect_true(idf$is_valid())
    # Request the raw field table because eplusr versions differ in the default
    # shape returned by `$to_table()` for a one-object class.
    run_period <- idf$to_table(class = "RunPeriod", all = TRUE)
    expect_equal(run_period$value[run_period$field == "Name"], "Annual")
    expect_equal(
        run_period$value[
            run_period$field == "Day of Week for Start Day"
        ],
        "Monday"
    )
    geometry_rules <- idf$to_table(class = "GlobalGeometryRules", all = TRUE)
    expect_equal(
        geometry_rules$value[
            geometry_rules$field == "Coordinate System"
        ],
        "Relative"
    )
    zone_geometry <- idf$to_table(class = "Zone", all = TRUE)
    expect_true(all(zone_geometry$value[
        zone_geometry$field %in% c(
            "Direction of Relative North", "X Origin", "Y Origin", "Z Origin"
        )
    ] == 0))

    validity <- idf$validate()
    issue_count <- vapply(validity, function(issue) {
        if (is.data.frame(issue)) nrow(issue) else length(issue)
    }, integer(1))
    expect_equal(issue_count, setNames(rep(0L, length(issue_count)), names(issue_count)))
})
