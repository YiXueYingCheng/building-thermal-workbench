# Store DeST hourly schedule data in the BLOB shape that readBin() expects when
# `schedule__convert()` reads SCHEDULE_YEAR.DATA from SQLite.
destep_test_schedule_blob <- function(values) {
    writeBin(as.double(values), raw(), size = 8L)
}

test_that("schedule conversion writes resolvable week day references", {
    ep <- ensure_empty_idf()
    dest <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
    on.exit(DBI::dbDisconnect(dest), add = TRUE)

    DBI::dbWriteTable(dest, "SCHEDULE_YEAR", data.frame(
        SCHEDULE_ID = 10L,
        NAME = "Always On",
        TYPE = 1L,
        DATA = I(list(destep_test_schedule_blob(rep(1, 8760L))))
    ))
    DBI::dbWriteTable(dest, "SCHEDULE_USAGE", data.frame(
        ID = 1L,
        SCHEDULE_ID = 10L
    ))

    schedule <- schedule__convert(dest, ep)
    value <- schedule$value

    week_day_names <- value$value_chr[
        value$class_name == "Schedule:Week:Compact" &
            grepl("^Schedule:Day Name", value$field_name)
    ]
    day_names <- value$value_chr[
        value$class_name == "Schedule:Day:Interval" &
            value$field_name == "Name"
    ]

    expect_false(anyNA(week_day_names))
    expect_true(all(unique(week_day_names) %in% day_names))
})

test_that("schedule conversion preserves weekday and weekend profiles", {
    ep <- ensure_empty_idf()
    dest <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
    on.exit(DBI::dbDisconnect(dest), add = TRUE)

    # The first seven DeST profiles represent Monday through Sunday. Repeat a
    # weekday-on/weekend-off pattern that exposes swapped day-profile links.
    weekly <- rep(c(rep(1, 5L), 0, 0), each = 24L)
    DBI::dbWriteTable(dest, "SCHEDULE_YEAR", data.frame(
        SCHEDULE_ID = 10L,
        NAME = "Weekday Availability",
        TYPE = 1L,
        DATA = I(list(destep_test_schedule_blob(rep(
            weekly,
            length.out = 8760L
        ))))
    ))
    DBI::dbWriteTable(dest, "SCHEDULE_USAGE", data.frame(
        ID = 1L,
        SCHEDULE_ID = 10L
    ))

    schedule <- schedule__convert(dest, ep)
    week <- schedule$value[class_name == "Schedule:Week:Compact"]
    first_week <- week[rleid == unique(week$rleid)[[1L]]]
    day <- schedule$value[
        class_name == "Schedule:Day:Interval" &
            field_name %in% c("Name", "Value Until Time 1")
    ]
    day_value <- day[field_name == "Value Until Time 1", value_num]
    names(day_value) <- day[field_name == "Name", value_chr]

    weekday_index <- which(first_week$value_chr == "For: Weekdays")
    weekend_index <- which(first_week$value_chr == "For: Weekends")
    weekday_name <- first_week$value_chr[weekday_index + 1L]
    weekend_name <- first_week$value_chr[weekend_index + 1L]

    expect_equal(unname(day_value[weekday_name]), 1)
    expect_equal(unname(day_value[weekend_name]), 0)
})

test_that("schedule conversion creates a dedicated week for a unique final day", {
    ep <- ensure_empty_idf()
    dest <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
    on.exit(DBI::dbDisconnect(dest), add = TRUE)

    # Mix a reusable schedule with one whose 365 daily profiles are all unique
    # so both the existing and dedicated week-53 paths run in one conversion.
    DBI::dbWriteTable(dest, "SCHEDULE_YEAR", data.frame(
        SCHEDULE_ID = c(10L, 20L),
        NAME = c("Always On", "Daily Ramp"),
        TYPE = c(1L, 4L),
        DATA = I(list(
            destep_test_schedule_blob(rep(1, 8760L)),
            destep_test_schedule_blob(rep(as.double(1:365), each = 24L))
        ))
    ))
    DBI::dbWriteTable(dest, "SCHEDULE_USAGE", data.frame(
        ID = 1:2,
        SCHEDULE_ID = c(10L, 20L)
    ))

    schedule <- schedule__convert(dest, ep)
    week <- schedule$value[class_name == "Schedule:Week:Compact"]
    final_week <- week[
        field_name == "Name" & value_chr == "Week-Daily Ramp (53)",
        rleid
    ]

    expect_length(final_week, 1L)
    expect_equal(
        week[rleid == final_week & field_name == "DayType List 1", value_chr],
        "For: AllDays"
    )
    final_day_name <- week[
        rleid == final_week & field_name == "Schedule:Day Name 1",
        value_chr
    ]
    final_day <- schedule$value[
        class_name == "Schedule:Day:Interval" &
            field_name == "Name" & value_chr == final_day_name,
        rleid
    ]
    expect_equal(
        schedule$value[
            rleid == final_day & field_name == "Value Until Time 1",
            value_num
        ],
        365
    )
    expect_true(any(
        schedule$value$class_name == "Schedule:Year" &
            schedule$value$value_chr == "Week-Daily Ramp (53)"
    ))
})

test_that("schedule conversion ignores missing and zero references", {
    ep <- ensure_empty_idf()
    dest <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
    on.exit(DBI::dbDisconnect(dest), add = TRUE)

    DBI::dbWriteTable(dest, "SCHEDULE_YEAR", data.frame(
        SCHEDULE_ID = 10L,
        NAME = "Always On",
        TYPE = 1L,
        DATA = I(list(destep_test_schedule_blob(rep(1, 8760L))))
    ))
    DBI::dbWriteTable(dest, "DOOR", data.frame(
        ID = 1:2,
        SCHEDULE = c(NA_integer_, NA_integer_)
    ))
    DBI::dbWriteTable(dest, "SCHEDULE_USAGE", data.frame(
        ID = 1:3,
        SCHEDULE_ID = c(10L, 0L, NA_integer_)
    ))

    schedule <- schedule__convert(dest, ep)

    expect_type(schedule, "list")
    expect_equal(attr(schedule, "table")$SCHEDULE_ID, 10L)
})

test_that("relative-humidity schedules convert DeST fractions to percent", {
    ep <- ensure_empty_idf()
    dest <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
    on.exit(DBI::dbDisconnect(dest), add = TRUE)

    DBI::dbWriteTable(dest, "SCHEDULE_YEAR", data.frame(
        SCHEDULE_ID = c(10L, 20L),
        NAME = c("RH Minimum", "RH Maximum"),
        TYPE = c(4L, 4L),
        DATA = I(list(
            destep_test_schedule_blob(rep(0.35, 8760L)),
            destep_test_schedule_blob(rep(0.60, 8760L))
        ))
    ))
    DBI::dbWriteTable(dest, "ROOM_GROUP", data.frame(
        ROOM_GROUP_ID = 1L,
        SET_RH_MIN_SCHEDULE = 10L,
        SET_RH_MAX_SCHEDULE = 20L
    ))

    schedule <- schedule__convert(dest, ep)
    table <- attr(schedule, "table")

    expect_equal(unique(table[SCHEDULE_ID == 10L]$DATA[[1L]]), 35)
    expect_equal(unique(table[SCHEDULE_ID == 20L]$DATA[[1L]]), 60)
})

test_that("relative-humidity schedule conversion rejects ambiguous reuse", {
    ep <- ensure_empty_idf()
    dest <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
    on.exit(DBI::dbDisconnect(dest), add = TRUE)

    DBI::dbWriteTable(dest, "SCHEDULE_YEAR", data.frame(
        SCHEDULE_ID = 10L,
        NAME = "Shared Schedule",
        TYPE = 4L,
        DATA = I(list(destep_test_schedule_blob(rep(0.35, 8760L))))
    ))
    DBI::dbWriteTable(dest, "ROOM_GROUP", data.frame(
        ROOM_GROUP_ID = 1L,
        SET_RH_MIN_SCHEDULE = 10L,
        SET_RH_MAX_SCHEDULE = 10L,
        AC_SCHEDULE_ID = 10L
    ))

    expect_error(
        schedule__convert(dest, ep),
        "also referenced by non-humidity fields"
    )
})

test_that("relative-humidity schedule conversion rejects unsupported units", {
    ep <- ensure_empty_idf()
    dest <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
    on.exit(DBI::dbDisconnect(dest), add = TRUE)

    DBI::dbWriteTable(dest, "SCHEDULE_YEAR", data.frame(
        SCHEDULE_ID = 10L,
        NAME = "RH Percent",
        TYPE = 4L,
        DATA = I(list(destep_test_schedule_blob(rep(35, 8760L))))
    ))
    DBI::dbWriteTable(dest, "ROOM_GROUP", data.frame(
        ROOM_GROUP_ID = 1L,
        SET_RH_MIN_SCHEDULE = 10L,
        SET_RH_MAX_SCHEDULE = 10L
    ))

    expect_error(
        schedule__convert(dest, ep),
        "fraction values in \\[0, 1\\]"
    )
})

test_that("relative-humidity schedule conversion rejects inverted bounds", {
    ep <- ensure_empty_idf()
    dest <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
    on.exit(DBI::dbDisconnect(dest), add = TRUE)

    DBI::dbWriteTable(dest, "SCHEDULE_YEAR", data.frame(
        SCHEDULE_ID = c(10L, 20L),
        NAME = c("RH Minimum", "RH Maximum"),
        TYPE = c(4L, 4L),
        DATA = I(list(
            destep_test_schedule_blob(rep(0.70, 8760L)),
            destep_test_schedule_blob(rep(0.60, 8760L))
        ))
    ))
    DBI::dbWriteTable(dest, "ROOM_GROUP", data.frame(
        ROOM_GROUP_ID = 1L,
        SET_RH_MIN_SCHEDULE = 10L,
        SET_RH_MAX_SCHEDULE = 20L
    ))

    expect_error(
        schedule__convert(dest, ep),
        "lower schedule 10 exceeds upper schedule 20"
    )
})

test_that("schedule conversion returns null without valid references", {
    ep <- ensure_empty_idf()
    dest <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
    on.exit(DBI::dbDisconnect(dest), add = TRUE)

    DBI::dbWriteTable(dest, "SCHEDULE_YEAR", data.frame(
        SCHEDULE_ID = 10L,
        NAME = "Always On",
        TYPE = 1L,
        DATA = I(list(destep_test_schedule_blob(rep(1, 8760L))))
    ))
    DBI::dbWriteTable(dest, "DOOR", data.frame(
        ID = 1:2,
        SCHEDULE = c(NA_integer_, NA_integer_)
    ))
    DBI::dbWriteTable(dest, "WINDOW", data.frame(
        ID = 1L,
        SCHEDULE = 0L
    ))

    expect_null(schedule__convert(dest, ep))
})

test_that("real model schedule week and year references are resolvable", {
    skip_on_cran()

    src <- ensure_dest_sqlite_file()
    on.exit(DBI::dbDisconnect(src), add = TRUE)

    idf <- to_eplus(src, 23.1)
    day <- idf$to_table(class = "Schedule:Day:Interval", all = TRUE)
    week <- idf$to_table(class = "Schedule:Week:Compact", all = TRUE)
    year <- idf$to_table(class = "Schedule:Year", all = TRUE)

    week_day_names <- week$value_chr[grepl("^Schedule:Day Name", week$field_name)]
    day_names <- day$value_chr[day$field_name == "Name"]
    year_week_names <- year$value_chr[grepl("^Schedule:Week Name", year$field_name)]
    week_names <- week$value_chr[week$field_name == "Name"]

    expect_false(anyNA(week_day_names))
    expect_true(all(unique(week_day_names) %in% day_names))
    expect_false(anyNA(year_week_names))
    expect_true(all(unique(year_week_names) %in% week_names))

    validity <- idf$validate()
    expect_equal(
        nrow(validity$missing_value[
            validity$missing_value$class_name == "Schedule:Week:Compact"
        ]),
        0L
    )
    expect_equal(
        nrow(validity$incomplete_extensible[
            validity$incomplete_extensible$class_name == "Schedule:Week:Compact"
        ]),
        0L
    )

    # AllOtherDays matches every still-unassigned day type, so EnergyPlus
    # requires it to follow the explicit Schedule:Week:Compact assignments.
    for (week_name in unique(week$name)) {
        daytypes <- week[
            name == week_name & grepl("^DayType List", field) & !is.na(value),
            value
        ]
        all_other <- which(daytypes == "For: AllOtherDays")
        if (length(all_other)) expect_equal(all_other, length(daytypes))
    }
})
