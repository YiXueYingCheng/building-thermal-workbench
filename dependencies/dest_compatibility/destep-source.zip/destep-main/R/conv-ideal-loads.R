# ROOM_GROUP air-conditioning availability -> ZoneHVAC:IdealLoadsAirSystem.
# This converter deliberately implements only the load-system shell: DeST
# supply-air state fields live in AC_SYS, and the current real fixture has no
# AC_SYS rows, so fixed EnergyPlus IdealLoads defaults are used here.
ideal_loads__convert <- function(dest, ep) {
    if (!db_has_rows(dest, "ROOM") || !db_has_rows(dest, "ROOM_GROUP")) {
        return(NULL)
    }

    ideal <- ideal_loads__room_group_table(dest)
    ideal_loads__assert_schedules(ideal)
    ideal_loads__assert_humidity_schedules(ideal)

    # Non-air-conditioned rooms stay in the diagnostic table but do not get
    # zone equipment. AC_T_* tolerance schedules are intentionally not used.
    skip_reason <- rep(NA_character_, nrow(ideal))
    skip_reason[is.na(ideal$ROOM_GROUP_ID)] <- "ROOM.OF_ROOM_GROUP does not reference ROOM_GROUP"
    missing_ac_flag <- is.na(skip_reason) & is.na(ideal$IS_AC_ROOM)
    skip_reason[missing_ac_flag] <- "ROOM_GROUP.IS_AC_ROOM is missing"
    non_ac_room <- is.na(skip_reason) & ideal$IS_AC_ROOM == 0L
    skip_reason[non_ac_room] <- "ROOM_GROUP.IS_AC_ROOM is zero"
    missing_schedule <- is.na(skip_reason) &
        (is.na(ideal$AC_SCHEDULE_ID) | ideal$AC_SCHEDULE_ID == 0L)
    skip_reason[missing_schedule] <- "ROOM_GROUP.AC_SCHEDULE_ID is zero or missing"
    data.table::set(ideal, NULL, "SKIP_REASON", skip_reason)
    data.table::set(ideal, NULL, "CAN_CONVERT", is.na(skip_reason))
    data.table::set(
        ideal, NULL, "HUMIDITY_CONTROL",
        ideal$CAN_CONVERT & ideal_loads__has_humidity_setpoints(ideal)
    )
    ideal <- ideal_loads__add_names(ideal)

    warning_skip <- !is.na(ideal$SKIP_REASON) &
        ideal$SKIP_REASON != "ROOM_GROUP.IS_AC_ROOM is zero"
    if (any(warning_skip)) {
        warn(sprintf(
            "Skipped %i ROOM row(s) that do not describe supported ROOM_GROUP ideal loads.",
            sum(warning_skip)
        ))
    }

    converted <- ideal[ideal$CAN_CONVERT]
    if (nrow(converted) == 0L) return(NULL)

    out <- conv__combine_outputs(list(
        humidistat = ideal_loads__humidistat_objects(
            dest, ep, converted[converted$HUMIDITY_CONTROL]
        ),
        ideal_loads = ideal_loads__objects(dest, ep, converted),
        sequential_fraction = ideal_loads__sequential_fraction_schedule(dest, ep),
        equipment_list = ideal_loads__equipment_lists(dest, ep, converted),
        equipment_connections = ideal_loads__equipment_connections(dest, ep, converted)
    ), table = ideal)

    out
}

# Collect room-group HVAC inputs and keep deferred DeST fields in the diagnostic
# table so future AC_SYS or AC_T_* work can compare against this converter.
ideal_loads__room_group_table <- function(dest) {
    ideal <- DBI::dbGetQuery(
        dest,
        "
        SELECT
            R.ID AS ROOM_ID,
            R.NAME AS ROOM_NAME,
            R.OF_ROOM_GROUP,
            G.ROOM_GROUP_ID,
            G.NAME AS ROOM_GROUP_NAME,
            G.OF_AC_SYS,
            G.IS_AC_ROOM,
            G.AC_SCHEDULE_ID,
            S_AC.NAME AS AC_SCHEDULE_NAME,
            G.SET_RH_MIN_SCHEDULE,
            S_RH_MIN.NAME AS HUMIDIFYING_SCHEDULE_NAME,
            G.SET_RH_MAX_SCHEDULE,
            S_RH_MAX.NAME AS DEHUMIDIFYING_SCHEDULE_NAME,
            G.AC_T_MIN_SCHEDULE,
            G.AC_T_MAX_SCHEDULE
        FROM ROOM R
        LEFT JOIN ROOM_GROUP G
        ON R.OF_ROOM_GROUP = G.ROOM_GROUP_ID
        LEFT JOIN SCHEDULE_YEAR S_AC
        ON G.AC_SCHEDULE_ID = S_AC.SCHEDULE_ID
        LEFT JOIN SCHEDULE_YEAR S_RH_MIN
        ON G.SET_RH_MIN_SCHEDULE = S_RH_MIN.SCHEDULE_ID
        LEFT JOIN SCHEDULE_YEAR S_RH_MAX
        ON G.SET_RH_MAX_SCHEDULE = S_RH_MAX.SCHEDULE_ID
        ORDER BY R.ID
        "
    )
    data.table::setDT(ideal)

    # Reuse occupant-derived outdoor-air objects when they exist; rooms without
    # a positive people fresh-air requirement keep the IdealLoads field blank.
    outdoor_air <- outdoor_air__occupant_table(dest)
    data.table::set(
        ideal, NULL, "ENERGYPLUS_OUTDOOR_AIR_NAME",
        outdoor_air$ENERGYPLUS_OUTDOOR_AIR_NAME[match(ideal$ROOM_ID, outdoor_air$ROOM_ID)]
    )

    ideal
}

# A supported humidity boundary needs both the lower humidification schedule and
# upper dehumidification schedule; zero in both fields means no humidity control.
ideal_loads__has_humidity_setpoints <- function(ideal) {
    !is.na(ideal$SET_RH_MIN_SCHEDULE) &
        ideal$SET_RH_MIN_SCHEDULE != 0L &
        !is.na(ideal$SET_RH_MAX_SCHEDULE) &
        ideal$SET_RH_MAX_SCHEDULE != 0L
}

# Fail before object generation when a conditioned room has a one-sided or
# dangling humidity schedule pair, because inventing a fallback would change
# the DeST moisture-control boundary frozen by H0.
ideal_loads__assert_humidity_schedules <- function(ideal) {
    supported <- !is.na(ideal$IS_AC_ROOM) & ideal$IS_AC_ROOM != 0L &
        !is.na(ideal$AC_SCHEDULE_ID) & ideal$AC_SCHEDULE_ID != 0L
    has_min <- !is.na(ideal$SET_RH_MIN_SCHEDULE) & ideal$SET_RH_MIN_SCHEDULE != 0L
    has_max <- !is.na(ideal$SET_RH_MAX_SCHEDULE) & ideal$SET_RH_MAX_SCHEDULE != 0L
    incomplete <- supported & xor(has_min, has_max)
    unresolved <- supported & (
        (has_min & is.na(ideal$HUMIDIFYING_SCHEDULE_NAME)) |
            (has_max & is.na(ideal$DEHUMIDIFYING_SCHEDULE_NAME))
    )

    if (!any(incomplete | unresolved)) return(invisible(NULL))

    rows <- ideal[incomplete | unresolved]
    detail <- paste(sprintf(
        paste0(
            "%s: SET_RH_MIN_SCHEDULE=%s, SET_RH_MAX_SCHEDULE=%s"
        ),
        rows$ROOM_NAME,
        rows$SET_RH_MIN_SCHEDULE,
        rows$SET_RH_MAX_SCHEDULE
    ), collapse = "; ")
    stop(sprintf(
        "Cannot resolve complete ROOM_GROUP humidity schedule pair(s): %s",
        detail
    ), call. = FALSE)
}

# Air-conditioned room groups with a non-zero availability schedule must resolve
# to SCHEDULE_YEAR; otherwise the generated IdealLoads objects would be invalid.
ideal_loads__assert_schedules <- function(ideal) {
    needs_schedule <- !is.na(ideal$IS_AC_ROOM) & ideal$IS_AC_ROOM != 0L &
        !is.na(ideal$AC_SCHEDULE_ID) & ideal$AC_SCHEDULE_ID != 0L
    unresolved <- needs_schedule & is.na(ideal$AC_SCHEDULE_NAME)

    if (!any(unresolved)) {
        return(invisible(NULL))
    }

    rows <- ideal[unresolved]
    detail <- paste(sprintf(
        "%s: AC_SCHEDULE_ID=%s",
        rows$ROOM_NAME,
        rows$AC_SCHEDULE_ID
    ), collapse = "; ")

    stop(sprintf(
        "Cannot resolve ROOM_GROUP ideal-loads schedule(s) in SCHEDULE_YEAR: %s",
        detail
    ), call. = FALSE)
}

# Generate stable, per-room node and object names required by the EnergyPlus
# zone equipment loop objects.
ideal_loads__add_names <- function(ideal) {
    data.table::set(
        ideal, NULL, "ENERGYPLUS_IDEAL_LOADS_NAME",
        make_unique_name(paste(ideal$ROOM_NAME, "Ideal Loads"))
    )
    data.table::set(
        ideal, NULL, "ENERGYPLUS_EQUIPMENT_LIST_NAME",
        make_unique_name(paste(ideal$ROOM_NAME, "Equipment"))
    )
    data.table::set(
        ideal, NULL, "ENERGYPLUS_HUMIDISTAT_NAME",
        make_unique_name(paste(ideal$ROOM_NAME, "Humidistat"))
    )
    data.table::set(
        ideal, NULL, "ZONE_SUPPLY_AIR_NODE_NAME",
        make_unique_name(paste(ideal$ROOM_NAME, "Ideal Loads Supply Node"))
    )
    data.table::set(
        ideal, NULL, "ZONE_EXHAUST_AIR_NODE_NAME",
        make_unique_name(paste(ideal$ROOM_NAME, "Ideal Loads Exhaust Node"))
    )
    data.table::set(
        ideal, NULL, "ZONE_AIR_NODE_NAME",
        make_unique_name(paste(ideal$ROOM_NAME, "Zone Air Node"))
    )
    data.table::set(
        ideal, NULL, "ZONE_RETURN_AIR_NODE_NAME",
        make_unique_name(paste(ideal$ROOM_NAME, "Zone Return Air Node"))
    )
    ideal
}

# Create one ZoneControl:Humidistat for every supported room with a complete
# DeST lower/upper relative-humidity schedule pair.
ideal_loads__humidistat_objects <- function(dest, ep, ideal) {
    if (nrow(ideal) == 0L) return(NULL)
    values <- lapply(seq_len(nrow(ideal)), function(i) {
        ideal_loads__humidistat_value(ideal, i)
    })

    conv__add_objects(dest, ep, "ZoneControl:Humidistat", values)
}

# Build the EnergyPlus humidistat value list for one converted DeST room group.
ideal_loads__humidistat_value <- function(ideal, i) {
    list(
        name = ideal$ENERGYPLUS_HUMIDISTAT_NAME[[i]],
        zone_name = ideal$ROOM_NAME[[i]],
        humidifying_relative_humidity_setpoint_schedule_name =
            ideal$HUMIDIFYING_SCHEDULE_NAME[[i]],
        dehumidifying_relative_humidity_setpoint_schedule_name =
            ideal$DEHUMIDIFYING_SCHEDULE_NAME[[i]]
    )
}

# Create IdealLoads systems with explicit EnergyPlus default-style supply-air
# limits; these are not inferred from DeST AC_T_* tolerance schedules.
ideal_loads__objects <- function(dest, ep, ideal) {
    values <- lapply(seq_len(nrow(ideal)), function(i) {
        ideal_loads__value(ideal, i)
    })

    conv__add_objects(dest, ep, "ZoneHVAC:IdealLoadsAirSystem", values)
}

# Build one ZoneHVAC:IdealLoadsAirSystem value list.
ideal_loads__value <- function(ideal, i) {
    outdoor_air_name <- ideal$ENERGYPLUS_OUTDOOR_AIR_NAME[[i]]
    if (is.na(outdoor_air_name)) {
        outdoor_air_name <- NULL
    }
    humidity_control <- isTRUE(ideal$HUMIDITY_CONTROL[[i]])

    list(
        name = ideal$ENERGYPLUS_IDEAL_LOADS_NAME[[i]],
        availability_schedule_name = ideal$AC_SCHEDULE_NAME[[i]],
        zone_supply_air_node_name = ideal$ZONE_SUPPLY_AIR_NODE_NAME[[i]],
        zone_exhaust_air_node_name = ideal$ZONE_EXHAUST_AIR_NODE_NAME[[i]],
        system_inlet_air_node_name = NULL,
        maximum_heating_supply_air_temperature = 50,
        minimum_cooling_supply_air_temperature = 13,
        maximum_heating_supply_air_humidity_ratio = 0.015,
        minimum_cooling_supply_air_humidity_ratio = 0.009,
        heating_limit = "NoLimit",
        maximum_heating_air_flow_rate = NULL,
        maximum_sensible_heating_capacity = NULL,
        cooling_limit = "NoLimit",
        maximum_cooling_air_flow_rate = NULL,
        maximum_total_cooling_capacity = NULL,
        heating_availability_schedule_name = NULL,
        cooling_availability_schedule_name = NULL,
        dehumidification_control_type = if (humidity_control) "Humidistat" else "None",
        cooling_sensible_heat_ratio = NULL,
        humidification_control_type = if (humidity_control) "Humidistat" else "None",
        design_specification_outdoor_air_object_name = outdoor_air_name,
        outdoor_air_inlet_node_name = NULL,
        demand_controlled_ventilation_type = "None",
        outdoor_air_economizer_type = "NoEconomizer",
        heat_recovery_type = "None",
        sensible_heat_recovery_effectiveness = 0,
        latent_heat_recovery_effectiveness = 0
    )
}

# The EquipmentList extensible group is complete only when the sequential load
# fraction schedule names are present, so a single constant-one schedule is
# shared by every generated IdealLoads equipment list.
ideal_loads__sequential_fraction_schedule <- function(dest, ep) {
    conv__add(
        dest, ep,
        "Schedule:Constant" := list(
            name = "DeST Ideal Loads Sequential Fraction",
            schedule_type_limits_name = NULL,
            hourly_value = 1
        )
    )
}

# Each conditioned zone gets a one-item equipment list that points to its own
# IdealLoads system.
ideal_loads__equipment_lists <- function(dest, ep, ideal) {
    values <- lapply(seq_len(nrow(ideal)), function(i) {
        ideal_loads__equipment_list_value(ideal, i)
    })

    conv__add_objects(dest, ep, "ZoneHVAC:EquipmentList", values)
}

# Build one ZoneHVAC:EquipmentList value list.
ideal_loads__equipment_list_value <- function(ideal, i) {
    list(
        name = ideal$ENERGYPLUS_EQUIPMENT_LIST_NAME[[i]],
        load_distribution_scheme = "SequentialLoad",
        zone_equipment_1_object_type = "ZoneHVAC:IdealLoadsAirSystem",
        zone_equipment_1_name = ideal$ENERGYPLUS_IDEAL_LOADS_NAME[[i]],
        zone_equipment_1_cooling_sequence = 1,
        zone_equipment_1_heating_or_no_load_sequence = 1,
        zone_equipment_1_sequential_cooling_fraction_schedule_name = "DeST Ideal Loads Sequential Fraction",
        zone_equipment_1_sequential_heating_fraction_schedule_name = "DeST Ideal Loads Sequential Fraction"
    )
}

# ZoneHVAC:EquipmentConnections closes the loop between a Zone, its equipment
# list, and the air nodes used by the IdealLoads system.
ideal_loads__equipment_connections <- function(dest, ep, ideal) {
    values <- lapply(seq_len(nrow(ideal)), function(i) {
        ideal_loads__equipment_connection_value(ideal, i)
    })

    conv__add_objects(dest, ep, "ZoneHVAC:EquipmentConnections", values)
}

# Build one ZoneHVAC:EquipmentConnections value list.
ideal_loads__equipment_connection_value <- function(ideal, i) {
    list(
        zone_name = ideal$ROOM_NAME[[i]],
        zone_conditioning_equipment_list_name = ideal$ENERGYPLUS_EQUIPMENT_LIST_NAME[[i]],
        zone_air_inlet_node_or_nodelist_name = ideal$ZONE_SUPPLY_AIR_NODE_NAME[[i]],
        zone_air_exhaust_node_or_nodelist_name = ideal$ZONE_EXHAUST_AIR_NODE_NAME[[i]],
        zone_air_node_name = ideal$ZONE_AIR_NODE_NAME[[i]],
        zone_return_air_node_or_nodelist_name = ideal$ZONE_RETURN_AIR_NODE_NAME[[i]]
    )
}
