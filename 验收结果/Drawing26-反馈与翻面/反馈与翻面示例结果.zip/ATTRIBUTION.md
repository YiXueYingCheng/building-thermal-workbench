# Example results attribution

Copyright (c) 2026 Zhao Bencheng.

Building Thermal Environment Workbench v0.72.0 — Drawing26 / ECA example results.
Package: 反馈与翻面示例结果.zip
Author: Zhao Bencheng
Contact: benchengchem@163.com
Affiliation: 426 Team, School of chemistry and chemical engineering, Jiangsu University.

The original reports, result tables and figures in this archive are licensed under Creative Commons Attribution 4.0 International (CC BY 4.0): https://creativecommons.org/licenses/by/4.0/ . The complete license is included in CC-BY-4.0.txt, including its disclaimer of warranties and limitation of liability.

When sharing, retain attribution and the license, and indicate whether changes were made. This archive contains unchanged numerical results from the reported validation runs; the license finalization did not run new simulations. Results apply only to the models, dates and conditions described in the reports. The standalone demonstration uses the previously verified model template; the source Drawing26 database has a known door-boundary issue in the generic importer (door 2892, two sides, approximately 71.56 mm outside the room-side host boundaries).

Recommended credit: Zhao Bencheng (2026), Building Thermal Environment Workbench v0.72.0, Drawing26 / ECA example results, CC BY 4.0.
